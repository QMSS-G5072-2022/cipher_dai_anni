# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['cipher_ad4056']

package_data = \
{'': ['*'],
 'cipher_ad4056': ['.idea/.gitignore',
                   '.idea/.gitignore',
                   '.idea/.gitignore',
                   '.idea/.gitignore',
                   '.idea/.gitignore',
                   '.idea/.gitignore',
                   '.idea/.name',
                   '.idea/.name',
                   '.idea/.name',
                   '.idea/.name',
                   '.idea/.name',
                   '.idea/.name',
                   '.idea/cipher_ad4056.iml',
                   '.idea/cipher_ad4056.iml',
                   '.idea/cipher_ad4056.iml',
                   '.idea/cipher_ad4056.iml',
                   '.idea/cipher_ad4056.iml',
                   '.idea/cipher_ad4056.iml',
                   '.idea/inspectionProfiles/*',
                   '.idea/misc.xml',
                   '.idea/misc.xml',
                   '.idea/misc.xml',
                   '.idea/misc.xml',
                   '.idea/misc.xml',
                   '.idea/misc.xml',
                   '.idea/modules.xml',
                   '.idea/modules.xml',
                   '.idea/modules.xml',
                   '.idea/modules.xml',
                   '.idea/modules.xml',
                   '.idea/modules.xml',
                   '.idea/vcs.xml',
                   '.idea/vcs.xml',
                   '.idea/vcs.xml',
                   '.idea/vcs.xml',
                   '.idea/vcs.xml',
                   '.idea/vcs.xml']}

setup_kwargs = {
    'name': 'cipher-ad4056',
    'version': '0.1.1',
    'description': 'cipher testesting for hw07',
    'long_description': '# cipher_ad4056\n\ncipher testesting for hw07\n\n## Installation\n\n```bash\n$ pip install cipher_ad4056\n```\n\n## Usage\n\n- TODO\n\n## Contributing\n\nInterested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.\n\n## License\n\n`cipher_ad4056` was created by Anni Dai. It is licensed under the terms of the MIT license.\n\n## Credits\n\n`cipher_ad4056` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).\n',
    'author': 'Anni Dai',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
